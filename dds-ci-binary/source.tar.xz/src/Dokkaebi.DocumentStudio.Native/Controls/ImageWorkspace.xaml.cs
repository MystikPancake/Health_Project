using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using Dokkaebi.DocumentStudio.Native.Documents;

namespace Dokkaebi.DocumentStudio.Native.Controls;

public partial class ImageWorkspace : UserControl, IDocumentWorkspace
{
    private readonly BitmapSource _original;
    private BitmapSource _current;
    private int _rotation;
    private bool _flip;

    public ImageWorkspace(string path)
    {
        InitializeComponent();
        FilePath = Path.GetFullPath(path); TitleText.Text = Title;
        using var input = File.OpenRead(FilePath);
        var decoder = BitmapDecoder.Create(input, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad);
        _original = decoder.Frames[0]; _original.Freeze(); _current = _original;
        ApplyTransform();
    }

    public string FilePath { get; }
    public string Title => Path.GetFileName(FilePath);
    public string WorkspaceKind => "Image";
    public FrameworkElement View => this;
    public bool IsDirty { get; private set; }
    public event EventHandler? DirtyStateChanged;

    public async Task SaveAsync(CancellationToken cancellationToken = default) => await SaveCopyAsync(FilePath, cancellationToken);

    public Task SaveCopyAsync(string outputPath, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        BitmapEncoder encoder = Path.GetExtension(outputPath).ToLowerInvariant() switch
        {
            ".jpg" or ".jpeg" => new JpegBitmapEncoder { QualityLevel = 94 },
            ".bmp" => new BmpBitmapEncoder(),
            ".gif" => new GifBitmapEncoder(),
            ".tif" or ".tiff" => new TiffBitmapEncoder(),
            _ => new PngBitmapEncoder()
        };
        encoder.Frames.Add(BitmapFrame.Create(_current));
        using var output = File.Create(Path.GetFullPath(outputPath)); encoder.Save(output);
        StatusText.Text = $"Saved image copy • {Path.GetFileName(outputPath)}";
        return Task.CompletedTask;
    }

    private void RotateLeftClick(object sender, RoutedEventArgs e) { _rotation = (_rotation + 270) % 360; MarkDirty(); ApplyTransform(); }
    private void RotateRightClick(object sender, RoutedEventArgs e) { _rotation = (_rotation + 90) % 360; MarkDirty(); ApplyTransform(); }
    private void FlipClick(object sender, RoutedEventArgs e) { _flip = !_flip; MarkDirty(); ApplyTransform(); }
    private void ResetClick(object sender, RoutedEventArgs e) { _rotation = 0; _flip = false; IsDirty = false; DirtyStateChanged?.Invoke(this, EventArgs.Empty); ApplyTransform(); }

    private void MarkDirty() { if (IsDirty) return; IsDirty = true; DirtyStateChanged?.Invoke(this, EventArgs.Empty); }

    private void ApplyTransform()
    {
        var group = new TransformGroup();
        if (_flip) group.Children.Add(new ScaleTransform(-1, 1));
        if (_rotation != 0) group.Children.Add(new RotateTransform(_rotation));
        _current = group.Children.Count == 0 ? _original : new TransformedBitmap(_original, group);
        if (_current.CanFreeze) _current.Freeze();
        PreviewImage.Source = _current;
        StatusText.Text = $"{_current.PixelWidth} × {_current.PixelHeight} • {_rotation}°{(_flip ? " • flipped" : string.Empty)}";
    }

    private async void SaveCopyClick(object sender, RoutedEventArgs e)
    {
        var dialog = new SaveFileDialog { FileName = Path.GetFileNameWithoutExtension(Title) + "-edited.png", Filter = "PNG image (*.png)|*.png|JPEG image (*.jpg)|*.jpg" };
        if (dialog.ShowDialog() != true) return;
        try { await SaveCopyAsync(dialog.FileName); } catch (Exception ex) { MessageBox.Show(ex.Message, "Save image", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    public void Dispose() { }
}
