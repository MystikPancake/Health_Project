using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using Dokkaebi.DocumentStudio.Native.Documents;

namespace Dokkaebi.DocumentStudio.Native.Controls;

public partial class TextDocumentWorkspace : UserControl, IDocumentWorkspace
{
    private bool _loading = true;
    public TextDocumentWorkspace(string path)
    {
        InitializeComponent();
        FilePath = Path.GetFullPath(path);
        TitleText.Text = Title;
        Editor.Text = File.ReadAllText(FilePath);
        StatusText.Text = $"{Path.GetExtension(FilePath).TrimStart('.').ToUpperInvariant()} • local DDS text editor";
        _loading = false;
    }

    public string FilePath { get; }
    public string Title => Path.GetFileName(FilePath);
    public string WorkspaceKind => "Text";
    public FrameworkElement View => this;
    public bool IsDirty { get; private set; }
    public event EventHandler? DirtyStateChanged;

    public async Task SaveAsync(CancellationToken cancellationToken = default)
    {
        await File.WriteAllTextAsync(FilePath, Editor.Text, cancellationToken);
        SetDirty(false); StatusText.Text = "Saved";
    }

    public async Task SaveCopyAsync(string outputPath, CancellationToken cancellationToken = default)
    {
        await File.WriteAllTextAsync(Path.GetFullPath(outputPath), Editor.Text, cancellationToken);
        StatusText.Text = $"Saved copy • {Path.GetFileName(outputPath)}";
    }

    private void TextChanged(object sender, TextChangedEventArgs e) { if (!_loading) SetDirty(true); }

    private void SetDirty(bool dirty)
    {
        if (IsDirty == dirty) return; IsDirty = dirty; DirtyStateChanged?.Invoke(this, EventArgs.Empty);
    }

    private async void SaveClick(object sender, RoutedEventArgs e)
    {
        try { await SaveAsync(); } catch (Exception ex) { MessageBox.Show(ex.Message, "Save text document", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private async void SaveCopyClick(object sender, RoutedEventArgs e)
    {
        var dialog = new SaveFileDialog { FileName = Title, Filter = "Text and structured files|*.txt;*.md;*.json;*.xml;*.html;*.csv|All files|*.*" };
        if (dialog.ShowDialog() != true) return;
        try { await SaveCopyAsync(dialog.FileName); } catch (Exception ex) { MessageBox.Show(ex.Message, "Save text copy", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private void FormatClick(object sender, RoutedEventArgs e)
    {
        try
        {
            var ext = Path.GetExtension(FilePath).ToLowerInvariant();
            if (ext == ".json")
            {
                using var json = JsonDocument.Parse(Editor.Text);
                Editor.Text = JsonSerializer.Serialize(json.RootElement, new JsonSerializerOptions { WriteIndented = true });
                StatusText.Text = "JSON formatted";
            }
            else if (ext == ".xml")
            {
                var doc = System.Xml.Linq.XDocument.Parse(Editor.Text, System.Xml.Linq.LoadOptions.PreserveWhitespace);
                Editor.Text = doc.ToString(); StatusText.Text = "XML formatted";
            }
            else StatusText.Text = "Formatting is available for JSON and XML documents";
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Format document", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    public void Dispose() { }
}
