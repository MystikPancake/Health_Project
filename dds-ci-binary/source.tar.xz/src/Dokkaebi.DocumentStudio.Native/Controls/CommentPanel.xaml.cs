using System.Windows;
using System.Windows.Controls;
using Dokkaebi.DocumentStudio.Native.Pdf;

namespace Dokkaebi.DocumentStudio.Native.Controls;

public partial class CommentPanel : UserControl
{
    public CommentPanel() => InitializeComponent();
    public event Action? HighlightRequested;
    public event Action? UnderlineRequested;
    public event Action? StrikeoutRequested;
    public event Action<string>? NoteRequested;
    public event Action<string>? SquareRequested;
    public event Action<int>? DeleteAnnotationRequested;

    public void SetAnnotations(IReadOnlyList<PdfAnnotationDescriptor> annotations)
    {
        AnnotationList.ItemsSource = annotations.Select(a => new AnnotationItem(a.Index, $"{a.Index + 1}. {a.Kind}" + (string.IsNullOrWhiteSpace(a.Contents) ? "" : $" — {a.Contents}"))).ToArray();
    }
    private void HighlightClick(object sender, RoutedEventArgs e) => HighlightRequested?.Invoke();
    private void UnderlineClick(object sender, RoutedEventArgs e) => UnderlineRequested?.Invoke();
    private void StrikeoutClick(object sender, RoutedEventArgs e) => StrikeoutRequested?.Invoke();
    private void NoteClick(object sender, RoutedEventArgs e) => NoteRequested?.Invoke(CommentText.Text.Trim());
    private void SquareClick(object sender, RoutedEventArgs e) => SquareRequested?.Invoke(CommentText.Text.Trim());
    private void DeleteAnnotationClick(object sender, RoutedEventArgs e) { if (AnnotationList.SelectedItem is AnnotationItem item) DeleteAnnotationRequested?.Invoke(item.Index); }
    private sealed record AnnotationItem(int Index, string Display);
}
