using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Dokkaebi.DocumentStudio.Native.Models;

namespace Dokkaebi.DocumentStudio.Native.Controls;

public partial class HomeWorkspace : UserControl
{
    private IReadOnlyList<RecentDocumentItem> _all = Array.Empty<RecentDocumentItem>();
    public HomeWorkspace() => InitializeComponent();

    public event Action? OpenRequested;
    public event Action<string>? RecentFileRequested;
    public event Action<string>? ToolRequested;

    public void SetRecents(IReadOnlyList<RecentDocumentItem> items)
    {
        _all = items;
        ShowItems(items, "Recent");
    }

    private void ShowItems(IEnumerable<RecentDocumentItem> items, string heading)
    {
        var list = items.ToArray();
        RecentHeading.Text = heading;
        RecentGrid.ItemsSource = list;
        RecentCards.ItemsSource = list;
    }

    private void OpenClick(object sender, RoutedEventArgs e) => OpenRequested?.Invoke();
    private void ToolClick(object sender, RoutedEventArgs e) { if (sender is FrameworkElement f && f.Tag is string tool) ToolRequested?.Invoke(tool); }
    private void RecentClick(object sender, RoutedEventArgs e) => ShowItems(_all, "Recent");
    private void StarredClick(object sender, RoutedEventArgs e) => ShowItems(_all.Where(x => x.IsStarred), "Starred");
    private void ComputerClick(object sender, RoutedEventArgs e) => OpenRequested?.Invoke();
    private void ScansClick(object sender, RoutedEventArgs e) => ShowItems(_all.Where(x => x.DisplayName.Contains("scan", StringComparison.OrdinalIgnoreCase)), "Scans");
    private void RecentGridDoubleClick(object sender, MouseButtonEventArgs e) { if (RecentGrid.SelectedItem is RecentDocumentItem item) RecentFileRequested?.Invoke(item.Path); }
    private void ListViewClick(object sender, RoutedEventArgs e) { RecentGrid.Visibility = Visibility.Visible; RecentCards.Visibility = Visibility.Collapsed; }
    private void GridViewClick(object sender, RoutedEventArgs e) { RecentGrid.Visibility = Visibility.Collapsed; RecentCards.Visibility = Visibility.Visible; }
}
