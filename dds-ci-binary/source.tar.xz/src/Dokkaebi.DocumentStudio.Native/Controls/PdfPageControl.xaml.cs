using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Dokkaebi.DocumentStudio.Native.Pdf;

namespace Dokkaebi.DocumentStudio.Native.Controls;

public partial class PdfPageControl : UserControl
{
    private CancellationTokenSource? _renderCts;
    private int _selectionAnchor = -1;
    private int _selectionActive = -1;
    private IReadOnlyList<PdfSearchHit> _searchHits = Array.Empty<PdfSearchHit>();
    private IReadOnlyList<PdfLink>? _links;
    private PdfPageObjectDescriptor? _selectedObject;

    public PdfPageControl() { InitializeComponent(); Loaded += (_, _) => _ = RenderAsync(); Unloaded += (_, _) => CancelRender(); }

    public PdfDocument? Document { get; set; }
    public PdfRenderCache? Cache { get; set; }
    public int PageIndex { get; set; }
    public double Zoom { get; set; } = 1.0;
    public int Rotation { get; set; }
    public string RenderIntent { get; set; } = "canvas";
    public bool IsInteractive { get; set; } = true;
    public PdfPageInfo PageInfo { get; private set; }
    public string SelectedText { get; private set; } = string.Empty;
    public bool ObjectEditMode { get; set; }
    public PdfPageObjectDescriptor? SelectedObject => _selectedObject;

    public event EventHandler<PdfSelectionChangedEventArgs>? SelectionChanged;
    public event EventHandler<string>? ExternalLinkClicked;
    public event EventHandler<PdfPageObjectSelectedEventArgs>? PageObjectSelected;

    public void Configure(PdfDocument document, PdfRenderCache cache, int pageIndex, double zoom, int rotation = 0, string intent = "canvas", bool interactive = true)
    {
        Document = document; Cache = cache; PageIndex = pageIndex; Zoom = PdfViewMath.ClampZoom(zoom); Rotation = PdfViewMath.NormalizeRotation(rotation); RenderIntent = intent; IsInteractive = interactive;
        PageInfo = document.GetPageInfo(pageIndex);
        UpdateDisplaySize();
    }

    public void SetSearchHits(IReadOnlyList<PdfSearchHit>? hits)
    {
        _searchHits = hits ?? Array.Empty<PdfSearchHit>();
        DrawSearchHits();
    }

    public async Task RenderAsync()
    {
        if (Document is null || !IsLoaded) return;
        CancelRender();
        _renderCts = new CancellationTokenSource();
        var token = _renderCts.Token;
        LoadingBadge.Visibility = Visibility.Visible;
        var dpi = VisualTreeHelper.GetDpi(this);
        var pixelWidth = Math.Max(1, (int)Math.Ceiling(ActualWidth * dpi.DpiScaleX));
        var pixelHeight = Math.Max(1, (int)Math.Ceiling(ActualHeight * dpi.DpiScaleY));
        var key = new PdfRenderCacheKey(Document.FilePath, PageIndex, pixelWidth, pixelHeight, Rotation, RenderIntent);
        try
        {
            PdfRenderedPage? rendered = null;
            if (Cache is not null) Cache.TryGet(key, out rendered);
            if (rendered is null)
            {
                rendered = await Task.Run(() => { token.ThrowIfCancellationRequested(); return Document.RenderPage(PageIndex, pixelWidth, pixelHeight, Rotation); }, token);
                if (Cache is not null) Cache.Put(key, rendered);
            }
            token.ThrowIfCancellationRequested();
            var bitmap = BitmapSource.Create(rendered.PixelWidth, rendered.PixelHeight, 96 * dpi.DpiScaleX, 96 * dpi.DpiScaleY, PixelFormats.Bgra32, null, rendered.Bgra32, rendered.Stride);
            bitmap.Freeze();
            PageImage.Source = bitmap;
            LoadingBadge.Visibility = Visibility.Collapsed;
            DrawSearchHits();
            DrawSelection();
            DrawFormFields();
            DrawObjectSelection();
        }
        catch (OperationCanceledException) { }
        catch (Exception ex)
        {
            LoadingBadge.Visibility = Visibility.Visible;
            if (LoadingBadge.Child is TextBlock text) { text.Text = "Page render failed\n" + ex.Message; text.TextAlignment = TextAlignment.Center; }
        }
    }

    private void UpdateDisplaySize()
    {
        var scale = (96.0 / 72.0) * Zoom;
        var w = PageInfo.WidthPoints * scale;
        var h = PageInfo.HeightPoints * scale;
        if (Rotation is 90 or 270) (w, h) = (h, w);
        Width = Math.Max(1, w); Height = Math.Max(1, h);
    }

    private void CancelRender() { _renderCts?.Cancel(); _renderCts?.Dispose(); _renderCts = null; }

    private void DrawSearchHits()
    {
        SearchOverlay.Children.Clear();
        if (Document is null || ActualWidth <= 0 || ActualHeight <= 0) return;
        foreach (var hit in _searchHits)
            foreach (var rect in Document.GetCharacterRects(PageIndex, hit.StartIndex, hit.Length)) AddPdfRect(SearchOverlay, rect, Color.FromArgb(80, 255, 210, 0), Color.FromArgb(170, 215, 160, 0));
    }

    private void DrawSelection()
    {
        SelectionOverlay.Children.Clear();
        SelectedText = string.Empty;
        if (Document is null || _selectionAnchor < 0 || _selectionActive < 0) return;
        var (start, end) = PdfViewMath.NormalizeSelection(_selectionAnchor, _selectionActive);
        var count = end - start + 1;
        foreach (var rect in Document.GetCharacterRects(PageIndex, start, count)) AddPdfRect(SelectionOverlay, rect, Color.FromArgb(80, 48, 111, 201), Color.FromArgb(110, 48, 111, 201));
        SelectedText = Document.GetTextRange(PageIndex, start, count);
    }

    private void AddPdfRect(Canvas canvas, PdfRect rect, Color fill, Color stroke)
    {
        if (Document is null) return;
        var p1 = Document.PageToDevice(PageIndex, Math.Max(1, (int)Math.Round(ActualWidth)), Math.Max(1, (int)Math.Round(ActualHeight)), Rotation, rect.Left, rect.Top);
        var p2 = Document.PageToDevice(PageIndex, Math.Max(1, (int)Math.Round(ActualWidth)), Math.Max(1, (int)Math.Round(ActualHeight)), Rotation, rect.Right, rect.Bottom);
        var left = Math.Min(p1.X, p2.X); var top = Math.Min(p1.Y, p2.Y); var width = Math.Max(1, Math.Abs(p2.X - p1.X)); var height = Math.Max(1, Math.Abs(p2.Y - p1.Y));
        var shape = new Rectangle { Width = width, Height = height, Fill = new SolidColorBrush(fill), Stroke = new SolidColorBrush(stroke), StrokeThickness = 0.5, IsHitTestVisible = false };
        Canvas.SetLeft(shape, left); Canvas.SetTop(shape, top); canvas.Children.Add(shape);
    }

    private void DrawFormFields()
    {
        FormOverlay.Children.Clear();
        if (Document is null || ActualWidth <= 0 || ActualHeight <= 0) return;
        foreach (var field in Document.GetFormFields().Where(f => f.PageIndex == PageIndex))
        {
            var p1 = Document.PageToDevice(PageIndex, Math.Max(1, (int)Math.Round(ActualWidth)), Math.Max(1, (int)Math.Round(ActualHeight)), Rotation, field.Bounds.Left, field.Bounds.Top);
            var p2 = Document.PageToDevice(PageIndex, Math.Max(1, (int)Math.Round(ActualWidth)), Math.Max(1, (int)Math.Round(ActualHeight)), Rotation, field.Bounds.Right, field.Bounds.Bottom);
            var left = Math.Min(p1.X, p2.X); var top = Math.Min(p1.Y, p2.Y); var width = Math.Max(4, Math.Abs(p2.X - p1.X)); var height = Math.Max(4, Math.Abs(p2.Y - p1.Y));
            var outline = new Border { Width = width, Height = height, BorderBrush = new SolidColorBrush(Color.FromArgb(125, 45, 108, 207)), BorderThickness = new Thickness(0.8), Background = string.IsNullOrWhiteSpace(field.Value) ? Brushes.Transparent : new SolidColorBrush(Color.FromArgb(225, 255, 255, 255)), IsHitTestVisible = false };
            if (!string.IsNullOrWhiteSpace(field.Value)) outline.Child = new TextBlock { Text = field.Value, Foreground = Brushes.Black, FontSize = Math.Clamp(height * 0.48, 8, 15), VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(2, 0, 2, 0), TextTrimming = TextTrimming.CharacterEllipsis };
            Canvas.SetLeft(outline, left); Canvas.SetTop(outline, top); FormOverlay.Children.Add(outline);
        }
    }

    private void DrawObjectSelection()
    {
        ObjectOverlay.Children.Clear();
        if (Document is null || _selectedObject is null || ActualWidth <= 0 || ActualHeight <= 0) return;
        var rect = _selectedObject.Bounds;
        var p1 = Document.PageToDevice(PageIndex, Math.Max(1, (int)Math.Round(ActualWidth)), Math.Max(1, (int)Math.Round(ActualHeight)), Rotation, rect.Left, rect.Top);
        var p2 = Document.PageToDevice(PageIndex, Math.Max(1, (int)Math.Round(ActualWidth)), Math.Max(1, (int)Math.Round(ActualHeight)), Rotation, rect.Right, rect.Bottom);
        var left = Math.Min(p1.X, p2.X); var top = Math.Min(p1.Y, p2.Y);
        var width = Math.Max(2, Math.Abs(p2.X - p1.X)); var height = Math.Max(2, Math.Abs(p2.Y - p1.Y));
        var outline = new Rectangle { Width = width, Height = height, Fill = Brushes.Transparent, Stroke = new SolidColorBrush(Color.FromRgb(34, 103, 196)), StrokeThickness = 1.4, StrokeDashArray = new DoubleCollection { 3, 2 }, IsHitTestVisible = false };
        Canvas.SetLeft(outline, left); Canvas.SetTop(outline, top); ObjectOverlay.Children.Add(outline);
        foreach (var pt in new[] { new Point(left, top), new Point(left + width / 2, top), new Point(left + width, top), new Point(left, top + height / 2), new Point(left + width, top + height / 2), new Point(left, top + height), new Point(left + width / 2, top + height), new Point(left + width, top + height) })
        {
            var handle = new Rectangle { Width = 6, Height = 6, Fill = Brushes.White, Stroke = new SolidColorBrush(Color.FromRgb(34, 103, 196)), StrokeThickness = 1, IsHitTestVisible = false };
            Canvas.SetLeft(handle, pt.X - 3); Canvas.SetTop(handle, pt.Y - 3); ObjectOverlay.Children.Add(handle);
        }
    }

    private PdfPageObjectDescriptor? HitPageObject(Point point)
    {
        if (Document is null) return null;
        var pdf = Document.DeviceToPage(PageIndex, Math.Max(1, (int)Math.Round(ActualWidth)), Math.Max(1, (int)Math.Round(ActualHeight)), Rotation, (int)Math.Round(point.X), (int)Math.Round(point.Y));
        if (double.IsNaN(pdf.X)) return null;
        return Document.EnumeratePageObjects(PageIndex)
            .Where(o => pdf.X >= Math.Min(o.Bounds.Left, o.Bounds.Right) && pdf.X <= Math.Max(o.Bounds.Left, o.Bounds.Right) && pdf.Y >= Math.Min(o.Bounds.Bottom, o.Bounds.Top) && pdf.Y <= Math.Max(o.Bounds.Bottom, o.Bounds.Top))
            .OrderBy(o => Math.Abs((o.Bounds.Right - o.Bounds.Left) * (o.Bounds.Top - o.Bounds.Bottom)))
            .FirstOrDefault();
    }

    public void ClearObjectSelection() { _selectedObject = null; DrawObjectSelection(); }

    private int HitCharacter(Point point)
    {
        if (Document is null) return -1;
        var pdf = Document.DeviceToPage(PageIndex, Math.Max(1, (int)Math.Round(ActualWidth)), Math.Max(1, (int)Math.Round(ActualHeight)), Rotation, (int)Math.Round(point.X), (int)Math.Round(point.Y));
        if (double.IsNaN(pdf.X)) return -1;
        return Document.GetCharIndexAtPosition(PageIndex, pdf.X, pdf.Y, 4, 4);
    }

    private void OnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (!IsInteractive || Document is null) return;
        Focus();
        if (ObjectEditMode)
        {
            _selectedObject = HitPageObject(e.GetPosition(this));
            DrawObjectSelection();
            PageObjectSelected?.Invoke(this, new PdfPageObjectSelectedEventArgs(PageIndex, _selectedObject));
            e.Handled = true; return;
        }
        CaptureMouse();
        _selectionAnchor = HitCharacter(e.GetPosition(this)); _selectionActive = _selectionAnchor;
        DrawSelection(); e.Handled = true;
    }

    private void OnMouseMove(object sender, MouseEventArgs e)
    {
        if (ObjectEditMode || !IsInteractive || !IsMouseCaptured || e.LeftButton != MouseButtonState.Pressed) return;
        var hit = HitCharacter(e.GetPosition(this));
        if (hit >= 0 && hit != _selectionActive) { _selectionActive = hit; DrawSelection(); }
    }

    private void OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (!IsInteractive || Document is null) return;
        if (ObjectEditMode) { e.Handled = true; return; }
        if (IsMouseCaptured) ReleaseMouseCapture();
        var (start, end) = _selectionAnchor >= 0 && _selectionActive >= 0 ? PdfViewMath.NormalizeSelection(_selectionAnchor, _selectionActive) : (-1, -1);
        if (start >= 0)
        {
            SelectionChanged?.Invoke(this, new PdfSelectionChangedEventArgs(PageIndex, start, end, SelectedText));
            if (start == end) TryActivateLink(e.GetPosition(this));
        }
        e.Handled = true;
    }

    private void TryActivateLink(Point point)
    {
        if (Document is null) return;
        _links ??= Document.GetWebLinks(PageIndex);
        var pdf = Document.DeviceToPage(PageIndex, Math.Max(1, (int)Math.Round(ActualWidth)), Math.Max(1, (int)Math.Round(ActualHeight)), Rotation, (int)Math.Round(point.X), (int)Math.Round(point.Y));
        foreach (var link in _links)
        {
            if (pdf.X >= link.Bounds.Left && pdf.X <= link.Bounds.Right && pdf.Y <= link.Bounds.Top && pdf.Y >= link.Bounds.Bottom && PdfViewMath.IsAllowedExternalUri(link.Url))
            { ExternalLinkClicked?.Invoke(this, link.Url); break; }
        }
    }

    private void OnPreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.C && Keyboard.Modifiers.HasFlag(ModifierKeys.Control) && !string.IsNullOrEmpty(SelectedText))
        { Clipboard.SetText(SelectedText); e.Handled = true; }
    }
}

public sealed class PdfSelectionChangedEventArgs : EventArgs
{
    public PdfSelectionChangedEventArgs(int pageIndex, int start, int end, string text) { PageIndex = pageIndex; Start = start; End = end; Text = text; }
    public int PageIndex { get; } public int Start { get; } public int End { get; } public string Text { get; }
}

public sealed class PdfPageObjectSelectedEventArgs : EventArgs
{
    public PdfPageObjectSelectedEventArgs(int pageIndex, PdfPageObjectDescriptor? selection) { PageIndex = pageIndex; Selection = selection; }
    public int PageIndex { get; }
    public PdfPageObjectDescriptor? Selection { get; }
}
