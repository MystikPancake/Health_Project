using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Dokkaebi.DocumentStudio.Native.Models;

namespace Dokkaebi.DocumentStudio.Native.Controls;

public partial class AllToolsPanel : UserControl
{
    public AllToolsPanel() => InitializeComponent();
    public event Action<string>? ToolInvoked;

    public void SetTools(IReadOnlyList<ToolDescriptor> tools)
    {
        ToolsHost.Children.Clear();
        foreach (var tool in tools)
        {
            var button = new IconButton
            {
                Label = tool.Label,
                Icon = Application.Current.TryFindResource(tool.IconKey) as Geometry,
                Style = (Style)FindResource("AllToolsItemButton"),
                Tag = tool.Id,
                ToolTip = tool.Description,
                HorizontalAlignment = HorizontalAlignment.Stretch,
                Margin = new Thickness(0, 0, 0, 2)
            };
            button.Click += ToolClick;
            ToolsHost.Children.Add(button);
        }
    }

    private void ToolClick(object sender, RoutedEventArgs e)
    {
        if (sender is FrameworkElement element && element.Tag is string id) ToolInvoked?.Invoke(id);
    }
}
