using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Dokkaebi.DocumentStudio.Native.Pdf;

namespace Dokkaebi.DocumentStudio.Native.Controls;

public partial class PdfThumbnailControl : UserControl
{
    private const double ThumbWidth = 118;
    private const double ItemGap = 12;
    private readonly Dictionary<int, Border> _realized = new();
    private readonly List<ItemLayout> _layouts = new();
    private PdfDocument? _document;
    private readonly PdfRenderCache _cache = new(32L * 1024 * 1024);
    private int _selectedPage;
    private readonly SortedSet<int> _selectedPages = new();
    private int _selectionAnchor;
    private Point _dragStart;

    public PdfThumbnailControl() { InitializeComponent(); Loaded += (_, _) => { BuildLayout(); EnsureVisible(); }; SizeChanged += (_, _) => { BuildLayout(); EnsureVisible(); }; }
    public event EventHandler<int>? PageSelected;
    public event Action<IReadOnlyList<int>>? SelectedPagesChanged;
    public event Action<int, int>? PageMoveRequested;
    public IReadOnlyList<int> SelectedPages => _selectedPages.ToArray();

    public void LoadDocument(PdfDocument document)
    { _document = document; _selectedPage = 0; _selectionAnchor = 0; _selectedPages.Clear(); if (document.PageCount > 0) _selectedPages.Add(0); _cache.Clear(); ClearRealized(); BuildLayout(); EnsureVisible(); RaiseSelectionChanged(); }

    public void RefreshDocument(int selectedPage = 0)
    {
        if (_document is null) return;
        _selectedPage = _document.PageCount == 0 ? 0 : Math.Clamp(selectedPage, 0, _document.PageCount - 1);
        _selectionAnchor = _selectedPage; _selectedPages.Clear(); if (_document.PageCount > 0) _selectedPages.Add(_selectedPage);
        _cache.Clear(); ClearRealized(); BuildLayout(); EnsureVisible(); UpdateSelectionBorders(); RaiseSelectionChanged();
    }

    public void SelectPage(int pageIndex, bool scrollIntoView = false)
    {
        _selectedPage = pageIndex; _selectionAnchor = pageIndex; _selectedPages.Clear(); _selectedPages.Add(pageIndex); UpdateSelectionBorders(); RaiseSelectionChanged();
        if (scrollIntoView)
        {
            var layout = _layouts.FirstOrDefault(x => x.PageIndex == pageIndex);
            if (layout is not null && (layout.Top < Viewport.VerticalOffset || layout.Bottom > Viewport.VerticalOffset + Viewport.ViewportHeight)) Viewport.ScrollToVerticalOffset(Math.Max(0, layout.Top - 8));
        }
    }

    private void BuildLayout()
    {
        _layouts.Clear(); if (_document is null) { Canvas.Height = 1; return; }
        var top = 10.0;
        for (var i = 0; i < _document.PageCount; i++)
        {
            var info = _document.GetPageInfo(i); var height = ThumbWidth / Math.Max(0.05, info.AspectRatio); var itemHeight = height + 26;
            _layouts.Add(new ItemLayout(i, top, height, itemHeight)); top += itemHeight + ItemGap;
        }
        Canvas.Width = Math.Max(150, ActualWidth - 8); Canvas.Height = Math.Max(1, top);
    }

    private void EnsureVisible()
    {
        if (_document is null || !IsLoaded) return;
        var top = Math.Max(0, Viewport.VerticalOffset - 250); var bottom = Viewport.VerticalOffset + Math.Max(500, Viewport.ViewportHeight + 250);
        var wanted = _layouts.Where(l => l.Bottom >= top && l.Top <= bottom).Select(l => l.PageIndex).ToHashSet();
        foreach (var p in _realized.Keys.Where(p => !wanted.Contains(p)).ToArray()) { Canvas.Children.Remove(_realized[p]); _realized.Remove(p); }
        foreach (var layout in _layouts.Where(l => wanted.Contains(l.PageIndex))) if (!_realized.ContainsKey(layout.PageIndex)) Realize(layout);
        UpdateSelectionBorders();
    }

    private void Realize(ItemLayout layout)
    {
        var border = new Border { Width = ThumbWidth + 18, Height = layout.ItemHeight, BorderThickness = new Thickness(1), BorderBrush = new SolidColorBrush(Color.FromRgb(210, 210, 210)), Background = Brushes.Transparent, Padding = new Thickness(8, 5, 8, 5), Cursor = Cursors.Hand, Tag = layout.PageIndex, AllowDrop = true };
        var panel = new StackPanel(); var image = new Image { Width = ThumbWidth, Height = layout.ImageHeight, Stretch = Stretch.Fill, SnapsToDevicePixels = true }; var label = new TextBlock { Text = (layout.PageIndex + 1).ToString(), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 5, 0, 0), FontSize = 11, Foreground = (Brush)FindResource("MutedBrush") };
        panel.Children.Add(image); panel.Children.Add(label); border.Child = panel;
        border.PreviewMouseLeftButtonDown += OnThumbnailMouseDown; border.MouseMove += OnThumbnailMouseMove; border.Drop += OnThumbnailDrop;
        Canvas.SetLeft(border, 8); Canvas.SetTop(border, layout.Top); Canvas.Children.Add(border); _realized[layout.PageIndex] = border; _ = RenderThumbAsync(layout, image);
    }

    private async Task RenderThumbAsync(ItemLayout layout, Image target)
    {
        if (_document is null) return;
        var dpi = VisualTreeHelper.GetDpi(this); var pw = Math.Max(1, (int)Math.Ceiling(ThumbWidth * dpi.DpiScaleX)); var ph = Math.Max(1, (int)Math.Ceiling(layout.ImageHeight * dpi.DpiScaleY));
        var key = new PdfRenderCacheKey(_document.FilePath, layout.PageIndex, pw, ph, 0, "thumbnail");
        PdfRenderedPage? rendered = null; _cache.TryGet(key, out rendered);
        rendered ??= await Task.Run(() => _document.RenderPage(layout.PageIndex, pw, ph, 0)); _cache.Put(key, rendered);
        if (!_realized.ContainsKey(layout.PageIndex)) return;
        var bitmap = BitmapSource.Create(rendered.PixelWidth, rendered.PixelHeight, 96 * dpi.DpiScaleX, 96 * dpi.DpiScaleY, PixelFormats.Bgra32, null, rendered.Bgra32, rendered.Stride); bitmap.Freeze(); target.Source = bitmap;
    }

    private void UpdateSelectionBorders()
    {
        foreach (var (page, border) in _realized) { var selected = _selectedPages.Contains(page); border.BorderBrush = selected ? (Brush)FindResource("AccentBrush") : new SolidColorBrush(Color.FromRgb(210, 210, 210)); border.BorderThickness = new Thickness(selected ? 2 : 1); border.Background = selected ? (Brush)FindResource("SelectedRailBrush") : Brushes.Transparent; }
    }

    private void OnThumbnailMouseDown(object sender, MouseButtonEventArgs e)
    {
        if (sender is not Border { Tag: int page }) return;
        _dragStart = e.GetPosition(this);
        var mods = Keyboard.Modifiers;
        if ((mods & ModifierKeys.Shift) != 0)
        {
            _selectedPages.Clear();
            var a = Math.Min(_selectionAnchor, page); var b = Math.Max(_selectionAnchor, page);
            for (var i = a; i <= b; i++) _selectedPages.Add(i);
        }
        else if ((mods & ModifierKeys.Control) != 0)
        {
            if (!_selectedPages.Add(page)) _selectedPages.Remove(page);
            if (_selectedPages.Count == 0) _selectedPages.Add(page);
            _selectionAnchor = page;
        }
        else
        {
            _selectedPages.Clear(); _selectedPages.Add(page); _selectionAnchor = page;
        }
        _selectedPage = page; UpdateSelectionBorders(); RaiseSelectionChanged(); PageSelected?.Invoke(this, page);
    }

    private void OnThumbnailMouseMove(object sender, MouseEventArgs e)
    {
        if (e.LeftButton != MouseButtonState.Pressed || sender is not Border { Tag: int page } || !_selectedPages.Contains(page)) return;
        var p = e.GetPosition(this);
        if (Math.Abs(p.X - _dragStart.X) < SystemParameters.MinimumHorizontalDragDistance && Math.Abs(p.Y - _dragStart.Y) < SystemParameters.MinimumVerticalDragDistance) return;
        DragDrop.DoDragDrop((DependencyObject)sender, page, DragDropEffects.Move);
    }

    private void OnThumbnailDrop(object sender, DragEventArgs e)
    {
        if (sender is not Border { Tag: int target } || !e.Data.GetDataPresent(typeof(int))) return;
        var source = (int)e.Data.GetData(typeof(int));
        if (source == target) return;
        PageMoveRequested?.Invoke(source, target);
        e.Handled = true;
    }

    private void RaiseSelectionChanged() => SelectedPagesChanged?.Invoke(_selectedPages.ToArray());

    private void ClearRealized() { foreach (var b in _realized.Values) Canvas.Children.Remove(b); _realized.Clear(); }
    private void OnScrollChanged(object sender, ScrollChangedEventArgs e) => EnsureVisible();
    private sealed record ItemLayout(int PageIndex, double Top, double ImageHeight, double ItemHeight) { public double Bottom => Top + ItemHeight; }
}
