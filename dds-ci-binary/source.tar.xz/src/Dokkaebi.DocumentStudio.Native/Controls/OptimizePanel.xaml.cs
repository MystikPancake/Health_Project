using System.Windows;
using System.Windows.Controls;
using Dokkaebi.DocumentStudio.Native.Services;

namespace Dokkaebi.DocumentStudio.Native.Controls;

public partial class OptimizePanel : UserControl
{
    public OptimizePanel() => InitializeComponent();
    public event Action<OptimizationPreset>? AnalyzeRequested;
    public event Action<OptimizationPreset>? OptimizeRequested;
    public event Action? RepairRequested;

    public void SetEngineAvailable(bool available)
    {
        OptimizeButton.IsEnabled = available; RepairButton.IsEnabled = available;
        if (!available) AnalysisText.Text = "qpdf is not available. Size analysis is still native, but Optimize and Repair stay disabled.";
    }

    public void SetAnalysis(PdfOptimizationAnalysis a)
    {
        AnalysisText.Text = $"File size: {FormatBytes(a.TotalBytes)}\nRaw image-stream references: {FormatBytes(a.RawImageBytes)} across {a.ImageObjects} image object(s)\nPage objects: {a.PageObjects:N0}\nOther / structural bytes: {FormatBytes(a.OtherBytes)}\n\nEstimated output: {FormatBytes(a.EstimatedOutputBytes)}\n{a.EstimateNote}";
    }

    public void SetResult(PdfToolOutput result)
    {
        ResultBorder.Visibility = Visibility.Visible;
        ResultText.Text = $"Actual output: {FormatBytes(result.OutputBytes)}\nInput: {FormatBytes(result.InputBytes)}\nReduction: {result.ReductionPercent:0.0}% ({FormatBytes(result.BytesSaved)})\n{result.Details}";
    }

    private OptimizationPreset CurrentPreset => PresetBox.SelectedIndex switch { 1 => OptimizationPreset.MaximumLossless, 2 => OptimizationPreset.ImageCompression, _ => OptimizationPreset.Balanced };
    private void AnalyzeClick(object sender, RoutedEventArgs e) => AnalyzeRequested?.Invoke(CurrentPreset);
    private void OptimizeClick(object sender, RoutedEventArgs e) => OptimizeRequested?.Invoke(CurrentPreset);
    private void RepairClick(object sender, RoutedEventArgs e) => RepairRequested?.Invoke();
    private static string FormatBytes(long bytes) => bytes >= 1024L * 1024 * 1024 ? $"{bytes / (1024d * 1024 * 1024):0.##} GB" : bytes >= 1024L * 1024 ? $"{bytes / (1024d * 1024):0.##} MB" : bytes >= 1024 ? $"{bytes / 1024d:0.##} KB" : $"{bytes} B";
}
