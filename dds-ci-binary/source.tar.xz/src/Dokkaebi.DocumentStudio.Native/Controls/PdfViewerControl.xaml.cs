using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Dokkaebi.DocumentStudio.Native.Pdf;

namespace Dokkaebi.DocumentStudio.Native.Controls;

public partial class PdfViewerControl : UserControl, IDisposable
{
    private const double PageGap = 18;
    private const double CanvasPadding = 30;
    private readonly PdfRenderCache _cache = new();
    private readonly Dictionary<int, PdfPageControl> _realized = new();
    private readonly List<PageLayout> _layouts = new();
    private readonly Dictionary<int, IReadOnlyList<PdfSearchHit>> _hitsByPage = new();
    private IReadOnlyList<PdfSearchHit> _searchHits = Array.Empty<PdfSearchHit>();
    private int _searchIndex = -1;
    private string _selectedText = string.Empty;
    private bool _disposed;
    private bool _objectEditMode;

    public PdfViewerControl() { InitializeComponent(); Loaded += (_, _) => { RebuildLayout(); EnsureVisiblePages(); }; }

    public PdfDocument? Document { get; private set; }
    public double Zoom { get; private set; } = 1.0;
    public int Rotation { get; private set; }
    public PdfViewMode ViewMode { get; private set; } = PdfViewMode.Continuous;
    public int CurrentPageIndex { get; private set; }
    public int SearchResultCount => _searchHits.Count;
    public int SearchResultIndex => _searchIndex;
    public PdfSelectionChangedEventArgs? CurrentSelection { get; private set; }
    public bool ObjectEditMode => _objectEditMode;

    public event EventHandler<int>? CurrentPageChanged;
    public event EventHandler<double>? ZoomChanged;
    public event EventHandler<string>? ExternalLinkClicked;
    public event EventHandler<string>? SelectionTextChanged;
    public event EventHandler? SearchStateChanged;
    public event EventHandler<PdfPageObjectSelectedEventArgs>? PageObjectSelected;

    public void LoadDocument(PdfDocument document)
    {
        ArgumentNullException.ThrowIfNull(document);
        ClearRealized(); _cache.Clear(); Document = document; CurrentPageIndex = 0; Zoom = 1; Rotation = 0; ViewMode = PdfViewMode.Continuous;
        _searchHits = Array.Empty<PdfSearchHit>(); _hitsByPage.Clear(); _searchIndex = -1; CurrentSelection = null;
        EmptyState.Visibility = document.PageCount == 0 ? Visibility.Visible : Visibility.Collapsed;
        RebuildLayout(); EnsureVisiblePages();
    }

    public void SetZoom(double zoom, bool keepCurrentPage = true)
    {
        var clamped = PdfViewMath.ClampZoom(zoom);
        if (Math.Abs(clamped - Zoom) < 0.0001) return;
        var page = CurrentPageIndex; Zoom = clamped; RebuildLayout();
        if (keepCurrentPage) GoToPage(page); else EnsureVisiblePages();
        ZoomChanged?.Invoke(this, Zoom);
    }

    public void ZoomIn() => SetZoom(Zoom * 1.10);
    public void ZoomOut() => SetZoom(Zoom / 1.10);
    public void ActualSize() => SetZoom(1.0);

    public void FitWidth()
    {
        if (Document is null || Document.PageCount == 0) return;
        var info = Document.GetPageInfo(CurrentPageIndex);
        var widthPoints = Rotation is 90 or 270 ? info.HeightPoints : info.WidthPoints;
        var available = Math.Max(100, Viewport.ViewportWidth - 2 * CanvasPadding - 18);
        SetZoom(available / (widthPoints * 96.0 / 72.0));
    }

    public void FitPage()
    {
        if (Document is null || Document.PageCount == 0) return;
        var info = Document.GetPageInfo(CurrentPageIndex);
        var widthPoints = Rotation is 90 or 270 ? info.HeightPoints : info.WidthPoints;
        var heightPoints = Rotation is 90 or 270 ? info.WidthPoints : info.HeightPoints;
        var availableW = Math.Max(100, Viewport.ViewportWidth - 2 * CanvasPadding - 18);
        var availableH = Math.Max(100, Viewport.ViewportHeight - 2 * CanvasPadding - 18);
        SetZoom(Math.Min(availableW / (widthPoints * 96.0 / 72.0), availableH / (heightPoints * 96.0 / 72.0)));
    }

    public void SetViewMode(PdfViewMode mode)
    {
        if (mode == ViewMode) return;
        var current = CurrentPageIndex; ViewMode = mode; RebuildLayout(); GoToPage(current);
    }

    public void RefreshDocument(int preferredPageIndex = -1)
    {
        if (Document is null) return;
        var page = preferredPageIndex >= 0 ? preferredPageIndex : CurrentPageIndex;
        _cache.Clear();
        _searchHits = Array.Empty<PdfSearchHit>();
        _hitsByPage.Clear();
        _searchIndex = -1;
        CurrentPageIndex = Document.PageCount == 0 ? 0 : Math.Clamp(page, 0, Document.PageCount - 1);
        EmptyState.Visibility = Document.PageCount == 0 ? Visibility.Visible : Visibility.Collapsed;
        RebuildLayout();
        if (Document.PageCount > 0) GoToPage(CurrentPageIndex); else EnsureVisiblePages();
        SearchStateChanged?.Invoke(this, EventArgs.Empty);
    }

    public void RotateViewClockwise()
    {
        Rotation = PdfViewMath.NormalizeRotation(Rotation + 90);
        var current = CurrentPageIndex; RebuildLayout(); GoToPage(current);
    }

    public void GoToPage(int pageIndex)
    {
        if (Document is null || Document.PageCount == 0) return;
        pageIndex = Math.Clamp(pageIndex, 0, Document.PageCount - 1);
        CurrentPageIndex = pageIndex;
        if (ViewMode == PdfViewMode.SinglePage) RebuildLayout();
        var layout = _layouts.FirstOrDefault(l => l.PageIndex == pageIndex);
        if (layout is not null) Viewport.ScrollToVerticalOffset(Math.Max(0, layout.Top - 8));
        EnsureVisiblePages(); CurrentPageChanged?.Invoke(this, pageIndex);
    }

    public async Task<int> SearchAsync(string query)
    {
        if (Document is null || string.IsNullOrWhiteSpace(query)) { ClearSearch(); return 0; }
        var doc = Document;
        var hits = await Task.Run(() => doc.Search(query));
        _searchHits = hits; _searchIndex = hits.Count > 0 ? 0 : -1; _hitsByPage.Clear();
        foreach (var group in hits.GroupBy(h => h.PageIndex)) _hitsByPage[group.Key] = group.ToArray();
        ApplySearchToRealized();
        if (_searchIndex >= 0) GoToPage(_searchHits[_searchIndex].PageIndex);
        SearchStateChanged?.Invoke(this, EventArgs.Empty);
        return hits.Count;
    }

    public void NextSearchHit()
    {
        if (_searchHits.Count == 0) return;
        _searchIndex = (_searchIndex + 1) % _searchHits.Count; GoToPage(_searchHits[_searchIndex].PageIndex); ApplySearchToRealized(); SearchStateChanged?.Invoke(this, EventArgs.Empty);
    }

    public void PreviousSearchHit()
    {
        if (_searchHits.Count == 0) return;
        _searchIndex = (_searchIndex - 1 + _searchHits.Count) % _searchHits.Count; GoToPage(_searchHits[_searchIndex].PageIndex); ApplySearchToRealized(); SearchStateChanged?.Invoke(this, EventArgs.Empty);
    }

    public void ShowTextRange(int pageIndex, int startIndex, int length, string preview = "Comparison difference")
    {
        if (Document is null || length <= 0) { ClearSearch(); if (Document is not null) GoToPage(pageIndex); return; }
        var hit = new PdfSearchHit(pageIndex, Math.Max(0, startIndex), Math.Max(1, length), preview);
        _searchHits = new[] { hit }; _searchIndex = 0; _hitsByPage.Clear(); _hitsByPage[pageIndex] = _searchHits; ApplySearchToRealized(); GoToPage(pageIndex); SearchStateChanged?.Invoke(this, EventArgs.Empty);
    }

    public void ClearSearch()
    {
        _searchHits = Array.Empty<PdfSearchHit>(); _hitsByPage.Clear(); _searchIndex = -1; ApplySearchToRealized(); SearchStateChanged?.Invoke(this, EventArgs.Empty);
    }

    public bool CopySelection()
    {
        if (string.IsNullOrEmpty(_selectedText)) return false;
        Clipboard.SetText(_selectedText); return true;
    }

    public void SetObjectEditMode(bool enabled)
    {
        _objectEditMode = enabled;
        foreach (var control in _realized.Values)
        {
            control.ObjectEditMode = enabled;
            if (!enabled) control.ClearObjectSelection();
        }
    }

    public void RefreshObjectSelection()
    {
        foreach (var control in _realized.Values) control.ClearObjectSelection();
    }

    private void RebuildLayout()
    {
        ClearRealized(); _layouts.Clear();
        if (Document is null || Document.PageCount == 0) { PageCanvas.Width = Math.Max(1, Viewport.ViewportWidth); PageCanvas.Height = Math.Max(1, Viewport.ViewportHeight); return; }
        var scale = 96.0 / 72.0 * Zoom;
        if (ViewMode == PdfViewMode.SinglePage)
        {
            var (w, h) = GetDisplaySize(CurrentPageIndex, scale); _layouts.Add(new PageLayout(CurrentPageIndex, CanvasPadding, CanvasPadding, w, h));
            PageCanvas.Width = w + 2 * CanvasPadding; PageCanvas.Height = h + 2 * CanvasPadding; return;
        }
        var top = CanvasPadding; var maxWidth = 0.0;
        if (ViewMode == PdfViewMode.Facing)
        {
            for (var i = 0; i < Document.PageCount; i += 2)
            {
                var (w1, h1) = GetDisplaySize(i, scale); var rowWidth = w1; var rowHeight = h1;
                _layouts.Add(new PageLayout(i, CanvasPadding, top, w1, h1));
                if (i + 1 < Document.PageCount)
                {
                    var (w2, h2) = GetDisplaySize(i + 1, scale); _layouts.Add(new PageLayout(i + 1, CanvasPadding + w1 + PageGap, top, w2, h2));
                    rowWidth += PageGap + w2; rowHeight = Math.Max(rowHeight, h2);
                }
                maxWidth = Math.Max(maxWidth, rowWidth); top += rowHeight + PageGap;
            }
        }
        else
        {
            for (var i = 0; i < Document.PageCount; i++)
            {
                var (w, h) = GetDisplaySize(i, scale); _layouts.Add(new PageLayout(i, CanvasPadding, top, w, h)); maxWidth = Math.Max(maxWidth, w); top += h + PageGap;
            }
        }
        PageCanvas.Width = maxWidth + 2 * CanvasPadding; PageCanvas.Height = Math.Max(1, top - PageGap + CanvasPadding);
    }

    private (double Width, double Height) GetDisplaySize(int pageIndex, double scale)
    {
        var info = Document!.GetPageInfo(pageIndex); var w = info.WidthPoints * scale; var h = info.HeightPoints * scale;
        if (Rotation is 90 or 270) (w, h) = (h, w); return (Math.Max(1, w), Math.Max(1, h));
    }

    private void EnsureVisiblePages()
    {
        if (Document is null || !IsLoaded) return;
        var top = Math.Max(0, Viewport.VerticalOffset - Math.Max(600, Viewport.ViewportHeight));
        var bottom = Viewport.VerticalOffset + Math.Max(1, Viewport.ViewportHeight) * 2;
        var wanted = _layouts.Where(l => l.Bottom >= top && l.Top <= bottom).Select(l => l.PageIndex).ToHashSet();
        foreach (var page in _realized.Keys.Where(p => !wanted.Contains(p)).ToArray()) { PageCanvas.Children.Remove(_realized[page]); _realized.Remove(page); }
        foreach (var layout in _layouts.Where(l => wanted.Contains(l.PageIndex)))
        {
            if (_realized.ContainsKey(layout.PageIndex)) continue;
            var control = new PdfPageControl(); control.Configure(Document, _cache, layout.PageIndex, Zoom, Rotation); control.Width = layout.Width; control.Height = layout.Height; control.ObjectEditMode = _objectEditMode;
            control.SelectionChanged += OnSelectionChanged; control.ExternalLinkClicked += (_, url) => ExternalLinkClicked?.Invoke(this, url);
            control.PageObjectSelected += (_, e) => PageObjectSelected?.Invoke(this, e);
            if (_hitsByPage.TryGetValue(layout.PageIndex, out var hits)) control.SetSearchHits(hits);
            Canvas.SetLeft(control, layout.Left); Canvas.SetTop(control, layout.Top); PageCanvas.Children.Add(control); _realized[layout.PageIndex] = control;
        }
        UpdateCurrentPageFromViewport();
    }

    private void UpdateCurrentPageFromViewport()
    {
        if (_layouts.Count == 0) return;
        var center = Viewport.VerticalOffset + Viewport.ViewportHeight / 2;
        var best = _layouts.OrderBy(l => Math.Abs((l.Top + l.Height / 2) - center)).First();
        if (best.PageIndex != CurrentPageIndex) { CurrentPageIndex = best.PageIndex; CurrentPageChanged?.Invoke(this, CurrentPageIndex); }
    }

    private void OnSelectionChanged(object? sender, PdfSelectionChangedEventArgs e)
    { CurrentSelection = e; _selectedText = e.Text; SelectionTextChanged?.Invoke(this, e.Text); }

    private void ApplySearchToRealized()
    {
        foreach (var (page, control) in _realized) control.SetSearchHits(_hitsByPage.TryGetValue(page, out var hits) ? hits : Array.Empty<PdfSearchHit>());
    }

    private void ClearRealized()
    {
        foreach (var control in _realized.Values) PageCanvas.Children.Remove(control); _realized.Clear();
    }

    private void OnScrollChanged(object sender, ScrollChangedEventArgs e) => EnsureVisiblePages();
    private void OnViewerSizeChanged(object sender, SizeChangedEventArgs e) { if (ViewMode == PdfViewMode.SinglePage) RebuildLayout(); EnsureVisiblePages(); }
    private void OnPreviewMouseWheel(object sender, MouseWheelEventArgs e)
    {
        if (!Keyboard.Modifiers.HasFlag(ModifierKeys.Control)) return;
        if (e.Delta > 0) ZoomIn(); else ZoomOut(); e.Handled = true;
    }

    public void Dispose()
    {
        if (_disposed) return; _disposed = true; ClearRealized(); _cache.Clear(); Document = null;
    }

    private sealed record PageLayout(int PageIndex, double Left, double Top, double Width, double Height) { public double Bottom => Top + Height; }
}
