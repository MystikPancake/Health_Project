using System.Windows;
using System.Windows.Controls;
using Dokkaebi.DocumentStudio.Native.Security;

namespace Dokkaebi.DocumentStudio.Native.Controls;

public sealed record CertificateUiOptions(string Reason, string Location, Uri? TimestampServer);

public partial class CertificatePanel : UserControl
{
    public CertificatePanel() => InitializeComponent();

    public event Action? RefreshRequested;
    public event Action<CertificateChoice, CertificateUiOptions>? StoreSignRequested;
    public event Action<CertificateUiOptions>? PfxSignRequested;
    public event Action? ValidateRequested;

    public void SetCertificates(IReadOnlyList<CertificateChoice> certificates)
    {
        CertificateBox.ItemsSource = certificates;
        if (certificates.Count > 0) CertificateBox.SelectedIndex = 0;
    }

    public void SetValidationResults(IReadOnlyList<SignatureValidationResult> results) => ValidationItems.ItemsSource = results;

    private CertificateUiOptions BuildOptions()
    {
        Uri? tsa = null;
        var raw = TimestampBox.Text.Trim();
        if (raw.Length > 0)
        {
            if (!Uri.TryCreate(raw, UriKind.Absolute, out tsa) || tsa.Scheme != Uri.UriSchemeHttps)
                throw new InvalidOperationException("Timestamp server must be an HTTPS URL.");
        }
        return new CertificateUiOptions(ReasonBox.Text.Trim(), LocationBox.Text.Trim(), tsa);
    }

    private void RefreshClick(object sender, RoutedEventArgs e) => RefreshRequested?.Invoke();

    private void SignStoreClick(object sender, RoutedEventArgs e)
    {
        if (CertificateBox.SelectedItem is not CertificateChoice certificate) return;
        try { StoreSignRequested?.Invoke(certificate, BuildOptions()); }
        catch (Exception ex) { MessageBox.Show(Window.GetWindow(this), ex.Message, "Certificate signing", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private void SignPfxClick(object sender, RoutedEventArgs e)
    {
        try { PfxSignRequested?.Invoke(BuildOptions()); }
        catch (Exception ex) { MessageBox.Show(Window.GetWindow(this), ex.Message, "Certificate signing", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private void ValidateClick(object sender, RoutedEventArgs e) => ValidateRequested?.Invoke();
}
