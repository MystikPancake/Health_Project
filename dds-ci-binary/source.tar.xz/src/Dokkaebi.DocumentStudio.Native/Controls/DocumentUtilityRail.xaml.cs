using System.Windows;
using System.Windows.Controls;

namespace Dokkaebi.DocumentStudio.Native.Controls;

public partial class DocumentUtilityRail : UserControl
{
    public DocumentUtilityRail() => InitializeComponent();
    public event Action? PagesRequested;
    public event Action? BookmarksRequested;
    public event Action? CommentsRequested;
    public event Action? AttachmentsRequested;
    public event Action? PropertiesRequested;
    public event Action? PreviousPageRequested;
    public event Action? NextPageRequested;
    public event Action? RotateRequested;
    public event Action? ZoomInRequested;
    public event Action? ZoomOutRequested;

    public void SetPageState(int currentPageIndex, int totalPages) => PageText.Text = totalPages <= 0 ? "0 / 0" : $"{currentPageIndex + 1} / {totalPages}";
    public void SetZoom(double zoom) => ZoomText.Text = $"{zoom * 100:0}%";

    private void PagesClick(object sender, RoutedEventArgs e) => PagesRequested?.Invoke();
    private void BookmarksClick(object sender, RoutedEventArgs e) => BookmarksRequested?.Invoke();
    private void CommentsClick(object sender, RoutedEventArgs e) => CommentsRequested?.Invoke();
    private void AttachmentsClick(object sender, RoutedEventArgs e) => AttachmentsRequested?.Invoke();
    private void PropertiesClick(object sender, RoutedEventArgs e) => PropertiesRequested?.Invoke();
    private void PreviousClick(object sender, RoutedEventArgs e) => PreviousPageRequested?.Invoke();
    private void NextClick(object sender, RoutedEventArgs e) => NextPageRequested?.Invoke();
    private void RotateClick(object sender, RoutedEventArgs e) => RotateRequested?.Invoke();
    private void ZoomInClick(object sender, RoutedEventArgs e) => ZoomInRequested?.Invoke();
    private void ZoomOutClick(object sender, RoutedEventArgs e) => ZoomOutRequested?.Invoke();
}
