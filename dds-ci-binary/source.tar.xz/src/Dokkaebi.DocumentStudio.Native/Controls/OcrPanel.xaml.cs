using System.Windows;
using System.Windows.Controls;
using Dokkaebi.DocumentStudio.Native.Services;

namespace Dokkaebi.DocumentStudio.Native.Controls;

public sealed record OcrUiRequest(string Mode, string Language);

public partial class OcrPanel : UserControl
{
    public OcrPanel() => InitializeComponent();
    public event Action<OcrUiRequest>? OcrRequested;
    public event Action? CancelRequested;

    public void SetLanguages(IReadOnlyList<string> languages)
    {
        LanguageBox.ItemsSource = languages;
        var eng = languages.Select((value, index) => new { value, index }).FirstOrDefault(x => string.Equals(x.value, "eng", StringComparison.OrdinalIgnoreCase));
        LanguageBox.SelectedIndex = eng?.index ?? (languages.Count > 0 ? 0 : -1);
    }

    public void SetBusy(bool busy)
    {
        StartButton.IsEnabled = !busy;
        CancelButton.IsEnabled = busy;
        ModeBox.IsEnabled = !busy;
        LanguageBox.IsEnabled = !busy;
    }

    public void SetProgress(OcrProgress progress)
    {
        Progress.Value = progress.Percentage;
        ProgressText.Text = progress.Status;
    }

    public void ResetProgress(string text = "Ready")
    {
        Progress.Value = 0;
        ProgressText.Text = text;
    }

    private void StartClick(object sender, RoutedEventArgs e)
    {
        if (LanguageBox.SelectedItem is not string language) return;
        var mode = (ModeBox.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "Current";
        OcrRequested?.Invoke(new OcrUiRequest(mode, language));
    }

    private void CancelClick(object sender, RoutedEventArgs e) => CancelRequested?.Invoke();
}
