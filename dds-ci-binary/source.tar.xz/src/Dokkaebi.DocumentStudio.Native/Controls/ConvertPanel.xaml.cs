using System.Windows;
using System.Windows.Controls;
using Dokkaebi.DocumentStudio.Native.Services;

namespace Dokkaebi.DocumentStudio.Native.Controls;

public partial class ConvertPanel : UserControl
{
    public ConvertPanel() => InitializeComponent();
    public event Action? CurrentPngRequested; public event Action? AllPngRequested; public event Action? TextRequested; public event Action? QpdfRequested; public event Action? TesseractRequested;
    public void SetCapabilities(EngineCapabilities c)
    {
        QpdfStatus.Text = c.HasQpdf ? "qpdf: available" : "qpdf: not detected"; QpdfButton.IsEnabled = c.HasQpdf;
        TesseractStatus.Text = c.HasTesseract ? "Tesseract: available" : "Tesseract: not detected"; TesseractButton.IsEnabled = c.HasTesseract;
        LibreOfficeStatus.Text = c.HasLibreOffice ? "LibreOffice: available for Office conversions" : "LibreOffice: not detected";
    }
    private void CurrentPngClick(object s,RoutedEventArgs e)=>CurrentPngRequested?.Invoke(); private void AllPngClick(object s,RoutedEventArgs e)=>AllPngRequested?.Invoke(); private void TextClick(object s,RoutedEventArgs e)=>TextRequested?.Invoke(); private void QpdfClick(object s,RoutedEventArgs e)=>QpdfRequested?.Invoke(); private void TesseractClick(object s,RoutedEventArgs e)=>TesseractRequested?.Invoke();
}
