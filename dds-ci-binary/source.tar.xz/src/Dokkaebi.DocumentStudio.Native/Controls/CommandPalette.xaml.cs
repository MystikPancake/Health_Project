using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Dokkaebi.DocumentStudio.Native.Services;

namespace Dokkaebi.DocumentStudio.Native.Controls;

public partial class CommandPalette : UserControl
{
    private IReadOnlyList<DdsCommandDescriptor> _commands = Array.Empty<DdsCommandDescriptor>();
    public event Action<string>? ToolInvoked;
    public event Action? Dismissed;

    public CommandPalette() => InitializeComponent();

    public void ShowCommands(IReadOnlyList<DdsCommandDescriptor> commands)
    {
        _commands = commands;
        Visibility = Visibility.Visible;
        FilterBox.Text = string.Empty;
        Filter(string.Empty);
        FilterBox.Focus();
    }

    public void HidePalette() => Visibility = Visibility.Collapsed;

    public void Filter(string query)
    {
        var q = query.Trim();
        var filtered = string.IsNullOrEmpty(q)
            ? _commands
            : _commands.Where(x => x.Label.Contains(q, StringComparison.OrdinalIgnoreCase) || x.Category.Contains(q, StringComparison.OrdinalIgnoreCase) || x.Id.Contains(q, StringComparison.OrdinalIgnoreCase)).ToArray();
        CommandList.ItemsSource = filtered;
        if (CommandList.Items.Count > 0) CommandList.SelectedIndex = 0;
    }

    private void FilterChanged(object sender, TextChangedEventArgs e) => Filter(FilterBox.Text);

    private void PaletteKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape) { HidePalette(); Dismissed?.Invoke(); e.Handled = true; return; }
        if (e.Key == Key.Down && ReferenceEquals(sender, FilterBox)) { if (CommandList.Items.Count > 0) { CommandList.Focus(); CommandList.SelectedIndex = Math.Max(0, CommandList.SelectedIndex); } e.Handled = true; return; }
        if (e.Key == Key.Enter) { ExecuteSelected(); e.Handled = true; }
    }

    private void CommandDoubleClick(object sender, MouseButtonEventArgs e) => ExecuteSelected();

    private void ExecuteSelected()
    {
        if (CommandList.SelectedItem is not DdsCommandDescriptor command) return;
        HidePalette();
        ToolInvoked?.Invoke(command.Id);
    }
}
