using System.IO;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using Dokkaebi.DocumentStudio.Native.Documents;
using Dokkaebi.DocumentStudio.Native.Pdf;

namespace Dokkaebi.DocumentStudio.Native.Controls;

public partial class OfficePreviewWorkspace : UserControl, IDocumentWorkspace
{
    private readonly string _previewPath;
    private readonly PdfDocument _document;
    private readonly PdfViewerControl _viewer;

    public OfficePreviewWorkspace(string originalPath, string previewPath)
    {
        InitializeComponent();
        FilePath = Path.GetFullPath(originalPath); _previewPath = Path.GetFullPath(previewPath); TitleText.Text = Title;
        _document = PdfDocument.Open(_previewPath); _viewer = new PdfViewerControl(); _viewer.LoadDocument(_document); PreviewHost.Content = _viewer;
    }

    public string FilePath { get; }
    public string Title => Path.GetFileName(FilePath);
    public string WorkspaceKind => "Office Preview";
    public FrameworkElement View => this;
    public bool IsDirty => false;
    public event EventHandler? DirtyStateChanged { add { } remove { } }
    public Task SaveAsync(CancellationToken cancellationToken = default) => Task.CompletedTask;
    public Task SaveCopyAsync(string outputPath, CancellationToken cancellationToken = default) { File.Copy(_previewPath, Path.GetFullPath(outputPath), true); return Task.CompletedTask; }

    private async void ExportPreviewClick(object sender, RoutedEventArgs e)
    {
        var dialog = new SaveFileDialog { FileName = Path.GetFileNameWithoutExtension(Title) + ".pdf", Filter = "PDF document (*.pdf)|*.pdf" };
        if (dialog.ShowDialog() != true) return;
        try { await SaveCopyAsync(dialog.FileName); } catch (Exception ex) { MessageBox.Show(ex.Message, "Export Office preview", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    public void Dispose()
    {
        _viewer.Dispose(); _document.Dispose();
        try { File.Delete(_previewPath); } catch { }
    }
}
