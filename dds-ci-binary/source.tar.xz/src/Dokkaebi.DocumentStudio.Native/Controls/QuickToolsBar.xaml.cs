using System.Windows;
using System.Windows.Controls;

namespace Dokkaebi.DocumentStudio.Native.Controls;

public partial class QuickToolsBar : UserControl
{
    public QuickToolsBar() => InitializeComponent();
    public event Action? SelectRequested;
    public event Action? AddTextRequested;
    public event Action? AddImageRequested;
    public event Action? CommentRequested;
    public event Action? HighlightRequested;
    public event Action? SignRequested;

    public void SetVertical(bool vertical) => ToolStack.Orientation = vertical ? Orientation.Vertical : Orientation.Horizontal;

    private void SelectClick(object sender, RoutedEventArgs e) => SelectRequested?.Invoke();
    private void AddTextClick(object sender, RoutedEventArgs e) => AddTextRequested?.Invoke();
    private void AddImageClick(object sender, RoutedEventArgs e) => AddImageRequested?.Invoke();
    private void CommentClick(object sender, RoutedEventArgs e) => CommentRequested?.Invoke();
    private void HighlightClick(object sender, RoutedEventArgs e) => HighlightRequested?.Invoke();
    private void SignClick(object sender, RoutedEventArgs e) => SignRequested?.Invoke();
}
