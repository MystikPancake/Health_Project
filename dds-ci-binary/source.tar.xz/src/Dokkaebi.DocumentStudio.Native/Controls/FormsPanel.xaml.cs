using System.Windows;
using System.Windows.Controls;
using Dokkaebi.DocumentStudio.Native.Pdf;

namespace Dokkaebi.DocumentStudio.Native.Controls;

public partial class FormsPanel : UserControl
{
    private IReadOnlyList<PdfFormFieldInfo> _fields = Array.Empty<PdfFormFieldInfo>();
    public FormsPanel() => InitializeComponent();
    public event Action<IReadOnlyList<PdfFormFieldInfo>>? ExportRequested;
    public event Action<PdfFormFieldInfo, string>? FieldValueRequested;
    public event Action<PdfFormFieldInfo>? DeleteFieldRequested;

    public void SetFields(IReadOnlyList<PdfFormFieldInfo> fields)
    {
        _fields = fields;
        SummaryText.Text = fields.Count == 0 ? "No AcroForm widget annotations were found." : $"{fields.Count} existing field(s) detected.";
        FieldsList.ItemsSource = fields.Select(f => new FieldItem(f, $"Page {f.PageIndex + 1} • {f.FieldName} • {f.FieldType}" + (string.IsNullOrWhiteSpace(f.Value) ? string.Empty : $" = {f.Value}"))).ToArray();
        FieldsList.SelectedIndex = fields.Count > 0 ? 0 : -1;
    }

    private void FieldSelected(object sender, SelectionChangedEventArgs e)
    {
        if (FieldsList.SelectedItem is not FieldItem item)
        {
            ValueBox.Text = string.Empty; ValueBox.IsEnabled = false; ApplyValueButton.IsEnabled = false; DeleteFieldButton.IsEnabled = false; return;
        }
        ValueBox.Text = item.Field.Value;
        var editable = item.Field.FieldType is "Text" or "Choice" or "Unknown";
        ValueBox.IsEnabled = editable; ApplyValueButton.IsEnabled = editable; DeleteFieldButton.IsEnabled = true;
        FieldHint.Text = editable ? "Apply updates the field's stored value using PDFium's public annotation API. DDS clears stale appearance data and renders the current value locally." : "This field type is view-only in the current safe authoring surface.";
    }

    private void ApplyValueClick(object sender, RoutedEventArgs e)
    { if (FieldsList.SelectedItem is FieldItem item) FieldValueRequested?.Invoke(item.Field, ValueBox.Text); }
    private void DeleteFieldClick(object sender, RoutedEventArgs e)
    { if (FieldsList.SelectedItem is FieldItem item) DeleteFieldRequested?.Invoke(item.Field); }
    private void ExportClick(object sender, RoutedEventArgs e) => ExportRequested?.Invoke(_fields);
    private sealed record FieldItem(PdfFormFieldInfo Field, string Display);
}
