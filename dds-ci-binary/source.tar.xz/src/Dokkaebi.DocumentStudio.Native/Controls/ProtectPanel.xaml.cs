using System.Windows;
using System.Windows.Controls;
using Dokkaebi.DocumentStudio.Native.Pdf;
using Dokkaebi.DocumentStudio.Native.Services;

namespace Dokkaebi.DocumentStudio.Native.Controls;

public partial class ProtectPanel : UserControl
{
    public ProtectPanel() => InitializeComponent();
    public event Action? ScanRequested;
    public event Action? RedactTextRequested;
    public event Action? RedactObjectRequested;
    public event Action<SanitizationOptions>? SanitizeRequested;

    public void SetSecurityReport(PdfSecurityReport report) => SecurityResult.Text = report.Summary + $"\n\nScanned {report.ScannedBytes:N0} bytes locally. Detection is structural and does not execute document content.";

    public void SetSanitizationAvailability(bool qpdfAvailable)
    {
        SanitizeButton.IsEnabled = qpdfAvailable;
        RemoveMetadataCheck.IsEnabled = qpdfAvailable;
        RemoveAttachmentsCheck.IsEnabled = qpdfAvailable;
        SanitizeAvailabilityText.Text = qpdfAvailable
            ? "qpdf secure rewrite engine detected."
            : "Secure metadata/attachment removal is hidden behind qpdf because PDFium-only attachment deletion can leave embedded payload bytes behind.";
    }

    public void SetSanitizationResult(SanitizationResult result)
    {
        SanitizationResultBorder.Visibility = Visibility.Visible;
        SanitizationResultText.Text = $"Verified sanitized copy\nRemoved categories: {string.Join(", ", result.RemovedCategories)}\nAttachments removed: {result.AttachmentsRemoved}\nRemaining detected risks: {result.After.RiskCount}\n\nDDS only claims the selected categories above were removed; other active-content indicators remain visible in the security report.";
        SetSecurityReport(result.After);
    }

    public void SetRedactionResult(PdfRedactionResult result)
    {
        RedactionResultBorder.Visibility = Visibility.Visible;
        var objects = result.RemovedObjects.Count == 0 ? "none" : string.Join(", ", result.RemovedObjects.GroupBy(x => x.Type).Select(g => $"{g.Count()} {g.Key}"));
        RedactionResultText.Text = $"Underlying objects removed: {result.RemovedCount}\nObject types: {objects}\nAn opaque cover was then added over the selected region.";
    }

    private void ScanClick(object sender, RoutedEventArgs e) => ScanRequested?.Invoke();
    private void RedactTextClick(object sender, RoutedEventArgs e) => RedactTextRequested?.Invoke();
    private void RedactObjectClick(object sender, RoutedEventArgs e) => RedactObjectRequested?.Invoke();
    private void SanitizeClick(object sender, RoutedEventArgs e) => SanitizeRequested?.Invoke(new SanitizationOptions(RemoveMetadataCheck.IsChecked == true, RemoveAttachmentsCheck.IsChecked == true));
}
