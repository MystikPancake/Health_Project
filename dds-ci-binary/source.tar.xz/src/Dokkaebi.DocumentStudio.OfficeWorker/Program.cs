using System.Diagnostics;
using System.IO.Pipes;
using System.Text;
using System.Text.Json;

namespace Dokkaebi.DocumentStudio.OfficeWorker;

public sealed record OfficeWorkerRequest(string Command, string? InputPath, string? OutputPath, string? Format);
public sealed record OfficeWorkerResponse(bool Success, string? OutputPath, string Message);

internal static class Program
{
    private static readonly HashSet<string> AllowedFormats = new(StringComparer.OrdinalIgnoreCase)
    { "pdf", "docx", "xlsx", "pptx", "odt", "ods", "odp", "rtf", "txt", "csv", "html" };

    public static async Task<int> Main(string[] args)
    {
        var pipeName = GetArg(args, "--pipe");
        var soffice = GetArg(args, "--libreoffice") ?? FindSoffice();
        if (string.IsNullOrWhiteSpace(pipeName)) return 2;

        using var pipe = new NamedPipeServerStream(pipeName, PipeDirection.InOut, 1, PipeTransmissionMode.Byte, PipeOptions.Asynchronous);
        await pipe.WaitForConnectionAsync();
        using var reader = new StreamReader(pipe, Encoding.UTF8, true, 4096, leaveOpen: true);
        using var writer = new StreamWriter(pipe, new UTF8Encoding(false), 4096, leaveOpen: true) { AutoFlush = true };
        OfficeWorkerResponse response;
        try
        {
            var line = await reader.ReadLineAsync();
            var request = string.IsNullOrWhiteSpace(line) ? null : JsonSerializer.Deserialize<OfficeWorkerRequest>(line);
            response = request is null ? new(false, null, "Invalid request") : await ExecuteAsync(request, soffice);
        }
        catch (Exception ex) { response = new(false, null, ex.Message); }
        await writer.WriteLineAsync(JsonSerializer.Serialize(response));
        return response.Success ? 0 : 1;
    }

    private static async Task<OfficeWorkerResponse> ExecuteAsync(OfficeWorkerRequest request, string? soffice)
    {
        switch (request.Command)
        {
            case "health":
                return File.Exists(soffice) ? new(true, null, "LibreOffice worker ready") : new(false, null, "LibreOffice executable was not found");
            case "save-copy":
                if (request.InputPath is null || request.OutputPath is null) return new(false, null, "Input and output paths are required");
                File.Copy(Path.GetFullPath(request.InputPath), Path.GetFullPath(request.OutputPath), true);
                return new(true, Path.GetFullPath(request.OutputPath), "Copy saved");
            case "open-preview":
                return await ConvertAsync(request.InputPath, request.OutputPath, "pdf", soffice);
            case "convert":
                return await ConvertAsync(request.InputPath, request.OutputPath, request.Format, soffice);
            default:
                return new(false, null, $"Unsupported worker command '{request.Command}'");
        }
    }

    private static async Task<OfficeWorkerResponse> ConvertAsync(string? inputPath, string? outputPath, string? format, string? soffice)
    {
        if (string.IsNullOrWhiteSpace(inputPath) || !File.Exists(inputPath)) return new(false, null, "Office input file was not found");
        if (string.IsNullOrWhiteSpace(outputPath)) return new(false, null, "Output path is required");
        if (string.IsNullOrWhiteSpace(format) || !AllowedFormats.Contains(format)) return new(false, null, "Requested output format is not allowed");
        if (string.IsNullOrWhiteSpace(soffice) || !File.Exists(soffice)) return new(false, null, "LibreOffice executable was not found");

        var input = Path.GetFullPath(inputPath); var output = Path.GetFullPath(outputPath);
        var tempDir = Path.Combine(Path.GetTempPath(), "DDS", "office-worker", Guid.NewGuid().ToString("N"));
        var profile = Path.Combine(tempDir, "profile"); Directory.CreateDirectory(tempDir); Directory.CreateDirectory(profile);
        try
        {
            var psi = new ProcessStartInfo(soffice) { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true };
            psi.ArgumentList.Add("--headless"); psi.ArgumentList.Add("--nologo"); psi.ArgumentList.Add("--nodefault"); psi.ArgumentList.Add("--nolockcheck");
            psi.ArgumentList.Add($"-env:UserInstallation={new Uri(profile).AbsoluteUri}");
            psi.ArgumentList.Add("--convert-to"); psi.ArgumentList.Add(format); psi.ArgumentList.Add("--outdir"); psi.ArgumentList.Add(tempDir); psi.ArgumentList.Add(input);
            using var process = Process.Start(psi) ?? throw new InvalidOperationException("Could not start LibreOffice worker process");
            using var timeout = new CancellationTokenSource(TimeSpan.FromMinutes(2));
            var stdout = process.StandardOutput.ReadToEndAsync(); var stderr = process.StandardError.ReadToEndAsync();
            await process.WaitForExitAsync(timeout.Token); var outText = await stdout; var errText = await stderr;
            if (process.ExitCode != 0) return new(false, null, string.IsNullOrWhiteSpace(errText) ? outText : errText);
            var produced = Directory.EnumerateFiles(tempDir).Where(x => !x.StartsWith(profile, StringComparison.OrdinalIgnoreCase)).FirstOrDefault(x => Path.GetExtension(x).Equals("." + format, StringComparison.OrdinalIgnoreCase));
            if (produced is null) return new(false, null, "LibreOffice did not produce the requested output file");
            Directory.CreateDirectory(Path.GetDirectoryName(output)!); File.Move(produced, output, true);
            return new(true, output, $"Converted to {format.ToUpperInvariant()}");
        }
        catch (OperationCanceledException) { return new(false, null, "LibreOffice conversion timed out"); }
        finally { try { Directory.Delete(tempDir, true); } catch { } }
    }

    private static string? GetArg(string[] args, string name)
    {
        var index = Array.FindIndex(args, x => string.Equals(x, name, StringComparison.OrdinalIgnoreCase));
        return index >= 0 && index + 1 < args.Length ? args[index + 1] : null;
    }

    private static string? FindSoffice()
    {
        var local = Path.Combine(AppContext.BaseDirectory, "engines", "libreoffice", "program", "soffice.exe");
        if (File.Exists(local)) return local;
        var path = Environment.GetEnvironmentVariable("PATH") ?? string.Empty;
        foreach (var dir in path.Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            try { var candidate = Path.Combine(dir.Trim('"'), "soffice.exe"); if (File.Exists(candidate)) return candidate; } catch { }
        }
        return null;
    }
}
