using Dokkaebi.DocumentStudio.Native.Pdf;

static void Eq<T>(T expected, T actual, string name) where T : notnull { if (!EqualityComparer<T>.Default.Equals(expected, actual)) throw new Exception($"{name}: expected {expected}, got {actual}"); }
static void Near(double expected, double actual, string name) { if (Math.Abs(expected-actual) > 0.001) throw new Exception($"{name}: expected {expected}, got {actual}"); }

Eq(0, PdfViewMath.NormalizeRotation(360), "rotation360");
Eq(270, PdfViewMath.NormalizeRotation(-90), "rotationNegative");
Eq((2, 9), PdfViewMath.NormalizeSelection(9, 2), "selection");
Near(0.5, PdfViewMath.FitWidth(532, 1000), "fitWidth");
Near(0.5, PdfViewMath.FitPage(532, 532, 1000, 1000), "fitPage");
Eq(true, PdfViewMath.IsAllowedExternalUri("https://example.com"), "httpsAllowed");
Eq(false, PdfViewMath.IsAllowedExternalUri("file:///c:/windows/system32/calc.exe"), "fileDenied");
var rect = PdfViewMath.PdfToView(new PdfRect(10, 80, 30, 100), 200, 2);
Near(20, rect.Left, "rectLeft"); Near(200, rect.Top, "rectTop");
Console.WriteLine("Native PDF pure tests: PASS");
